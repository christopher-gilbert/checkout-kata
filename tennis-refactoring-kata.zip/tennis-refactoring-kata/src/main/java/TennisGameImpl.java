
public class TennisGameImpl implements TennisGame {

    private int score1 = 0;
    private int score2 = 0;
    private String player1Name;
    private String player2Name;

    private static int GAME_POINT_SCORE = 4;

    public TennisGameImpl(String player1Name, String player2Name) {
        this.player1Name = player1Name;
        this.player2Name = player2Name;
    }

    /**
     * Add a point to the player with {@code playerName}.
     * <p>
     * Assumes the passed in name is one of {@link #player1Name}  or {@link #player2Name}
     */
    public void wonPoint(String playerName) {
        if (player1Name.equals(playerName)) {
            score1 += 1;
        } else {
            score2 += 1;
        }
    }

    /**
     * Determine a textual representation of the current score based on standard tennis laws.
     */
    public String getScore() {
        if (score1 == score2) {
            return equalScoring(score1);
        } else if (score1 >= GAME_POINT_SCORE || score2 >= GAME_POINT_SCORE) {
            return gamePointOrWin();
        } else {
            return defaultScoring(score1) + "-" + defaultScoring(score2);
        }
    }

    private String equalScoring(int score) {
        switch (score) {
            case 0:
                return "Love-All";
            case 1:
                return "Fifteen-All";
            case 2:
                return "Thirty-All";
            default:
                return "Deuce";
        }
    }

    private String gamePointOrWin() {
        int difference = score1 - score2;
        String messageTemplate = Math.abs(difference) == 1 ? "Advantage %s" : "Win for %s";
        String winningPlayer = score1 > score2 ? player1Name : player2Name;
        return String.format(messageTemplate, winningPlayer);
    }

    private String defaultScoring(int score) {

        switch (score) {
            case 0:
                return "Love";
            case 1:
                return "Fifteen";
            case 2:
                return "Thirty";
            default:
                return "Forty";
        }
    }

}
